#include "auction\design\maps.pwn"
#include "design\biznes_centre.pwn"
#include "dialogs\to_do_rate.pwn"
#include "dialogs\car_take.pwn"
#include "design\textdraws.pwn"
#include "functions\auction_menu_managment.pwn"
#include "functions\GetPlayerID.pwn"
#include "functions\strfmt.pwn"
#include "functions\TimeConverter.pwn"


