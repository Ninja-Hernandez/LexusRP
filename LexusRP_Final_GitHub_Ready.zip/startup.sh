#!/bin/bash

echo "🔧 اجرای سرور SA-MP - LexusRP"

# بررسی گیم‌مود
if [ ! -f "gamemodes/new.amx" ]; then
  echo "❌ gamemodes/new.amx پیدا نشد!"
  exit 1
fi

# بررسی پلاگین‌ها
REQUIRED_PLUGINS=("mysql.so" "sscanf.so" "streamer.so" "crashdetect.so" "pawncmd.so" "pawnraknet.so" "TOTP.so" "profiler.so" "CRP.so")
for plugin in "${REQUIRED_PLUGINS[@]}"; do
  if [ ! -f "plugins/$plugin" ]; then
    echo "❌ پلاگین $plugin پیدا نشد."
    exit 1
  fi
done

# دادن دسترسی اجرا و اجرای سرور
chmod +x samp03svr
echo "🚀 اجرای سرور..."
./samp03svr
